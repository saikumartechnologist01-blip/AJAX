import logo from './logo.svg';
import './App.css';
import axios from 'axios';
import { useEffect, useState } from 'react';

function App() {

   const [products, setProducts] = useState([]);

   const addProduct = async () => {


   }

   const fetchProducts = async () => {
      const response = await axios.get("http://localhost:9090/products");
      console.log(response.data);
      setProducts(response.data);
   }

   const editProduct = async (id) => {

   }

    const deleteProduct = async (id) => {
    }
   const iterateProducts = () => {
      return products.map(product => (
         <tr key={product.id}>
            <td>{product.id}</td>
            <td>{product.name}</td>
            <td>{product.price}</td>
            <td>
               <button style={{backgroundColor:'orange'}} onClick={() => editProduct(product.id)}>Edit</button>
               <button style={{backgroundColor:'red'}} onClick={() => deleteProduct(product.id)}>Delete</button>
            </td>
         </tr>
      ));
   }

    useEffect(() => {
      fetchProducts();
    }, []);

  return (
    <div className="App">
      
       <h1>Product Manager</h1>
        <div className="form-container">
        <input type="text" id="name" placeholder="Enter product name" />
        <input type="number" id="price" placeholder="Enter price" />
        <button id="toggleBtn" onClick={() => addProduct()}>Add Product</button>
    </div>

     <table id="productTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Price</th>
                 <th>Edit / Delete</th>
            </tr>
        </thead>
        <tbody>
{iterateProducts()}
        </tbody>
    </table>

    </div>
  );
}

export default App;
