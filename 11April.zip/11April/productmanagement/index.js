const express = require("express");
const app = express();
const cors = require("cors");

app.use(cors());
app.use(express.json());


// In-memory storage
let products = [
    {
        id: 1,
        name: "Sample Product",
        price: 19.99
    },
    {
        id: 2,
        name: "Another Product",
        price: 29.99
    }
];
let currentId = 3;
/**
 * GET all products
 */
app.get("/products", (req, res) => {
  res.json(products);
});

/**
 * GET single product by ID
 */
app.get("/products/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const product = products.find(p => p.id === id);

  if (!product) {
    return res.status(404).json({ message: "Product not found" });
  }

  res.json(product);
});

/**
 * POST create new product
 */
app.post("/products", (req, res) => {
  const { name, price } = req.body;

  if (!name || price == null) {
    return res.status(400).json({ message: "Name and price are required" });
  }

  const newProduct = {
    id: currentId++,
    name,
    price
  };

  products.push(newProduct);
  res.status(201).json(newProduct);
});

/**
 * PUT update product
 */
app.put("/products/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const { name, price } = req.body;

  const product = products.find(p => p.id === id);

  if (!product) {
    return res.status(404).json({ message: "Product not found" });
  }

  if (name !== undefined) product.name = name;
  if (price !== undefined) product.price = price;

  res.json(product);
});

/**
 * DELETE product
 */
app.delete("/products/:id", (req, res) => {
  const id = parseInt(req.params.id);

  const index = products.findIndex(p => p.id === id);

  if (index === -1) {
    return res.status(404).json({ message: "Product not found" });
  }

  const deletedProduct = products.splice(index, 1);

  res.json({
    message: "Product deleted",
    product: deletedProduct[0]
  });
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});